import NumberCard from './numberCard'

export { NumberCard }